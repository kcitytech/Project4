var slider = document.getElementById("range");

slider.oninput = function() {

document.getElementById("adaflex").src="img/ada2.jpg";

}
